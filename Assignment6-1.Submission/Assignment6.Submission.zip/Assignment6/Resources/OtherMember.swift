import Foundation

struct OtherMember: Identifiable, Decodable {
  let id: UUID
  let name: String
}
