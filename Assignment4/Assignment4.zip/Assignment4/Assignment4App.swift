import SwiftUI

@main
struct Assignment4App: App {
    var body: some Scene {
        WindowGroup {
            Assignment4View()
        }
    }
}
