//
//  Message.swift
//  Assignment5
//
//  Created by Abhinav Sunil on 5/8/23.
//

import Foundation


struct Message: Identifiable, Decodable {
  let id: UUID
  let content: String
  let posted: String
  let member: Member
}
